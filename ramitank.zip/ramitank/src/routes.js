
export const Routes = {
    // pages
    Home: { path: "/" },
    About: { path: "about" },
	Services:{ path: "service" },
	Features:{ path: "feature" },
	Price:{ path: "price" },
	Team: { path: "team" },
	Category: { path: "category" },
	Contact: { path: "contact" },
};