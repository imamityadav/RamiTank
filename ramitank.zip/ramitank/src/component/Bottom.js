import React from 'react'

const Bottom = () => {
  return (
	<>
	<div className="container-fluid text-white" style={{background: "#061429"}}>
        <div className="container text-center">
            <div className="row justify-content-end">
                <div className="col-lg-8 col-md-6">
                    <div className="d-flex align-items-center justify-content-center" style={{height: "75px"}}>
                        <p className="mb-0">&copy; 
                        <a className="text-white border-bottom" href="#">
                          Your Site Name
                          All Rights Reserved.
                          </a>. 
                           
						 {/* This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support.}
						Designed by  */}
            <a className="text-white border-bottom" href="#">HTML Codex</a></p>
            <br/>Distributed By: <a className="border-bottom" href="#" target="_blank">ThemeWagon</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	</>
  )
}

export default Bottom