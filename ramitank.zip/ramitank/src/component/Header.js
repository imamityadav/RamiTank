import React from 'react'
import {Link,useLocation } from "react-router-dom";
import { Routes } from '../routes';

const Header = (props) => {
    const location = useLocation();
  return (
	<>
	 <div className="container-fluid position-relative p-0">
        <nav className="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0">
            <Link to={Routes.Home.path} className="navbar-brand p-0">
                <h1 className="m-0"><i className="fa fa-user-tie me-2"></i>RamiTank</h1>
            </Link>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span className="fa fa-bars"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarCollapse">
                <div className="navbar-nav ms-auto py-0">  
                    <Link to={Routes.Home.path} className={`nav-item nav-link ${location.pathname === "/" ? `active` : ``} `}>Home</Link>
                    <Link to={Routes.About.path} className={`nav-item nav-link ${location.pathname === "/about" ? `active` : ``} `}>About</Link>
                    <Link to={Routes.Services.path} className={`nav-item nav-link ${location.pathname === "/service" ? `active` : ``} `}>Services</Link>
                    <Link to={Routes.Contact.path} className={`nav-item nav-link ${location.pathname === "/contact" ? `active` : ``} `}>Contact</Link>
                </div>
                <button type="button" className="btn text-primary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal"><i className="fa fa-search"></i></button>
            </div>
        </nav>
    </div>
	</>
  )
}

export default Header