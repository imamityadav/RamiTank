import React from "react";
import Bottom from "../component/Bottom";
import Footer from "../component/Footer";
import Header from "../component/Header";
import Search from "../component/Search";
import Spinner from "../component/Spinner";
import Topbar from "../component/Topbar";
import UpDown from "../component/UpDown";
import About from "./About";
import Category from "./Category";
import Contact from "./Contact";
import Features from "./Features";
import Price from "./Price";
import Services from "./Services";
import Team from "./Team";
import {Routes as getRoutes } from '../routes';
import {Routes,Route} from "react-router-dom";

const App = () => {
  return (
    <>
      {/* Spinner Component Start*/}
      <Spinner />
      {/* Spinner Component End */}
       {/* Topbar  Component Start */}
      <Topbar />
      {/* Topbar  Component End  */}
      {/* Header ComponentStart  */}
      <Header />
      {/* <!-- Header Component End --> */}
      {/* <!-- Full Screen Search  Component Start --> */}
      <Search />
       {/* <!-- Full Screen Search Component End --> */}
      <Routes>
       <Route exact path={getRoutes.Home.path}  element={<Team />}/> 
      {/* <!-- About Page Start --> */}
      <Route  path={getRoutes.About.path}  element={<About />}/>
      {/* <!-- About Page End --> */}
      {/* <!-- Features Page Start --> */}
      <Route path={getRoutes.Features.path} element={<Features />}/>
      {/* <!-- Features Page Start --> */}
      {/* <!-- Service Page Start --> */}
      <Route path={getRoutes.Services.path}  element={<Services />}/>
      {/* <!-- Service  Page End --> */}
      {/* <!-- Pricing Plan Start --> */}
      <Route  path={getRoutes.Price.path} element={<Price />}/>
      {/* <!-- Pricing Plan End --> */}
      {/* <!-- Contact Component Start --> */}
      <Route  path={getRoutes.Contact.path}  element={<Contact />}/>
      {/* <!-- Contact Component End --> */}
      {/* <!-- Team  Component Start --> */}
      <Route path={getRoutes.Team.path} element={<Team />}/>
      {/* <!-- Team Component End --> */}
      {/* <!-- Category Component Start --> */}
      <Route path={getRoutes.Category.path} element={<Category />}/>
      {/* <!-- Category Component End --> */}
      </Routes>
      {/* <!-- Footer  Component Start --> */}
      <Footer />
      <Bottom />
      {/* <!-- Footer Component End --> */}
      <UpDown />
    </>
  );
};

export default App;
